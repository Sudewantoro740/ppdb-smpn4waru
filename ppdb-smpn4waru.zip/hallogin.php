<!DOCTYPE html>
<html>
<head>
	<title>Pendaftaran PPDB Online SMPN 4 Waru</title>
	<link rel="icon" href="gambar/logo.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
	<style type="text/css">
		body {
			background-color: #e3e1e1;
		}
		.header {
			padding: 80px;
			text-align: center;
			display: flex;
			justify-content: center;
			height: 60vh;
			flex-direction: column;
			align-items: center;
		}
		form:before {
		    content: '';
		    height: 100%;
		    left: 0;
		    position: absolute;
		    top: 0;
		    width: 100%;
		    z-index: -1;
		    border-radius: 10px;
			background-color: #343a40;
		}
		p {
			color:white;
			transition: all 0.5s ease;
		}
		p:hover {
			color: #007bff;
			margin-left:10px ;
		}
	</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<a class="navbar-brand" href="https://www.smpn4waru.sch.id/">
    	<img src="gambar/logo.png" width="55" height="50" class="d-inline-block align-center"> SMPN 4 WARU
  	</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item">
				<a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
			</li>
			<li class="nav-item active">
				<a class="nav-link" href="hallogin.php">Login</a>
			</li>
			<li class="nav-item">
        		<a class="nav-link" href="daftarakun.php">Registrasi</a>
      		</li>
			<li class="nav-item">
        		<a class="nav-link" href="informasi.php">Informasi</a>
      		</li>
      		<li class="nav-item">
        		<a class="nav-link" href="tentang.php">Tentang</a>
      		</li>
		</ul>
		<span class="navbar-text">
      		PPDB Online SMPN 4 Waru
    	</span>
	</div>
</nav>

<div class="container" style="padding-top: 100px;">
    <div class="row text-white">
        <div class="col-xl-5 col-lg-6 col-md-8 col-sm-10 mx-auto text-center form p-4 ">
            <h1 class="display-4 py-2 text-truncate">Login Disini</h1>
            <div class="px-2">
				<?php 
					if(isset($_GET['pesan'])){
						if($_GET['pesan'] == "gagal"){
							echo '<div class="alert alert-warning" role="alert">Login gagal! NISN dan Password salah!</div>';
						}else if($_GET['pesan'] == "logout"){
							echo '<div class="alert alert-success" role="alert">Anda Telah Berhasil Logout</div>';
						}else if($_GET['pesan'] == "belum_login"){
							echo '<div class="alert alert-warning" role="alert">Anda Harus Login Untuk Mengaksesnya</div>';
						}
					}
				?>
                <form action="login.php" method="post">
					<div class="justify-content-center">
						<div class="form-group">
							<label class="sr-only">NISN</label>
							<input type="text" class="form-control" placeholder="NISN" name="nisn">
						</div>
						<div class="form-group">
							<label class="sr-only">Password</label>
							<input type="password" class="form-control" placeholder="Password" name="password">
						</div>
                    	<button type="submit" name="login" value="login" class="btn btn-primary btn-lg">Login</button>
					</div>
					<a href="daftarakun.php"><p align="left">Belum Punya Akun?</p></a>
                </form>
            </div>
        </div>
    </div>
</div>

</body>
</html>