<?php
session_start();
if($_SESSION['level']==""){
	header("location:../hallogin.php?pesan=belum_login");
}
include "koneksiuser.php";
$nisn1 = $_SESSION['nisn'];
$sql2="SELECT nisn FROM formulir where nisn = '".$nisn1."'";
$qry = mysqli_query($koneksi, $sql2) or die ("Proses cetak gagal");
	if (mysqli_num_rows($qry)==1) {
		header("location:pendaftaran.php?pesanpendaftaran=sudah");
	}else{
		$sql = "INSERT INTO `formulir`(`nama`,`jkel`,`nisn`,`nik`,`tlahir`,`tgllahir`,`noakta`,`agama`,`kwn`,`bkhusus`,`alamat`,`rt`,`rw`,`nmdusun`,`kelurahan`,`kecamatan`,`kdpos`,`lintang`,`bujur`,`ttinggal`,`transportasi`,`nokks`,`anakke`,`kps`,`nokps`)VALUES ('$nama','$jkel','$nisn','$nik','$tlahir','$tgllahir','$noakta','$agama','$kwn','$bkhusus','$alamat','$rt','$rw','$nmdusun','$kelurahan','$kecamatan','$kdpos','$lintang','$bujur','$ttinggal','$transportasi','$nokks','$anakke','$kps','$nokps')";
		mysqli_query($koneksi,$sql) or die (mysqli_error());
		header("location:pendaftaran.php?pesanpendaftaran=baru");
	}
?>