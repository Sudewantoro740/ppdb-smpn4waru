<!DOCTYPE html>
<html>
<head>
	<title>Selamat Datang di PPDB Online SMPN 4 Waru</title>
	<link rel="icon" href="gambar/logo.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
	<style type="text/css">
		body {
			background-color: #e3e1e1;
		}
		.header {
			padding-top: 20vw;
			padding-bottom: 30vw;
			text-align: center;
			display: flex;
			justify-content: center;
			height: 60vh;
			flex-direction: column;
			align-items: center;
		}
	</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<a class="navbar-brand" href="https://www.smpn4waru.sch.id/">
    	<img src="gambar/logo.png" width="55" height="50" class="d-inline-block align-center"> SMPN 4 WARU
  	</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item active">
				<a class="nav-link" href="index.php">Home</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="hallogin.php">Login</a>
			</li>
			<li class="nav-item">
        		<a class="nav-link" href="daftarakun.php">Registrasi</a>
      		</li>
			<li class="nav-item">
        		<a class="nav-link" href="informasi.php">Informasi</a>
      		</li>
      		<li class="nav-item">
        		<a class="nav-link" href="tentang.php">Tentang</a>
      		</li>
		</ul>
		<span class="navbar-text">
      		PPDB Online SMPN 4 Waru
    	</span>
	</div>
</nav>

<div class="header">
	<h1>Selamat Datang di Pendaftaran SMPN 4 Waru</h1>
	<p>Silahkan Login <a href="hallogin.php">Disini</a></p>
</div>

<!-- Footer -->
<footer class="page-footer font-small pt-4" style="background-color: #8a8888">
  <!-- Footer Links -->
  <div class="container-fluid text-center text-md-left ">
    <!-- Grid row -->
    <div class="row">
      <!-- Grid column -->
      	<div class="col-md-6 mt-md-0 mt-3">
	        <!-- Content -->
	        <h5 class="text-uppercase">sistem informasi</h5>
	        <p>Universitas Pembangunan Nasional “Veteran” Jawa Timur</p>
		</div>
		<!-- Grid column -->
		<hr class="clearfix w-100 d-md-none pb-3">
		<!-- Grid column -->
		<div class="col-md-4 mb-md-0 mb-3">
	        <!-- Links -->
	        <h5 class="text-uppercase">pembuat</h5>
	        <ul class="list-unstyled">
          		<li>
            		<p>Sudewantoro Nur Muhammad (18082010039)</p>
				</li>
				<li>
	            	<p>Fariza Nanda Sabila (18082010009)</p>
	          	</li>
        	</ul>
		</div>
		<!-- Grid column -->
    </div>
    <!-- Grid row -->
	</div>
	<!-- Footer Links -->
	<!-- Copyright -->
  		<div class="footer-copyright text-center py-3 bg-dark text-white">© 2020 Copyright:
			<a href="https://www.smpn4waru.sch.id/">SMPN 4 Waru</a>
  		</div>
  	<!-- Copyright -->
</footer>
</body>
</html>