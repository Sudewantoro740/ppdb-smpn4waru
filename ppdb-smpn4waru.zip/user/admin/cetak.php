<?php 
session_start();
if($_SESSION['level']==""){
	header("location:../../hallogin.php?pesan=belum_login");
	exit();
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>ADMIN</title>
	<link rel="icon" href="../../gambar/admin.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
 	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	<style type="text/css">
		body {
			background-color: #e3e1e1;
		}
		.header {
			padding: 80px;
			text-align: center;
			display: flex;
			justify-content: center;
			height: 60vh;
			flex-direction: column;
			align-items: center;
		}
	</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<a class="navbar-brand" href="homeadmin.php">
    	<img src="../../gambar/admin.png" width="55" height="50" class="d-inline-block align-center"> ADMIN
  	</a>

	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item">
				<a class="nav-link" href="homeadmin.php">Home <span class="sr-only">(current)</span></a>
			</li>
			<li class="nav-item active">
				<a class="nav-link" href="cetak.php">Cetak <span class="sr-only">(current)</span></a>
			</li>
		</ul>
		<ul class="navbar-nav ml-auto">
			<li class="nav-item">
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#logout">
  					Log Out
				</button>
	      	</li>	
		</ul>
    </div>
</nav>
<div class="modal" id="logout">
    <div class="modal-dialog">
      	<div class="modal-content">
	        <div class="modal-header">
	          	<h4 class="modal-title">Log Out</h4>
	          	<button type="button" class="close" data-dismiss="modal">&times;</button>
	        </div>
	        <div class="modal-body">
	          	Apakah Yakin Ingin Keluar?
	        </div>
	        <div class="modal-footer">
        		<a href="../logout.php" class="btn btn-primary">Log Out</a>
	          	<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
	        </div>
      	</div>
    </div>
</div>
  
<div class="container" style="padding-top: 100px;">
<div class="row">
<div class="col">
	<div class="card-header bg-dark text-white">
		<h4>Cetak Data Akun Siswa</h4>
	</div>
	<div class="card-body bg-white">
		<p>Tabel dibawah digunakan untuk mencetak seluruh data siswa yang mendaftar di website ini.</p>
		<table class="table table-bordered table-dark">
  		<thead>
	    <tr>
			<th scope="col">No</th>
			<th scope="col">Formulir</th>
			<th scope="col">Cetak</th>
	    </tr>
	  	</thead>
	  	<tbody>
	    <tr>
	      	<th scope="row">1</th>
	      	<td rowspan="2">Data Peserta</td>
	      	<td><a href="cetakpdfadmin.php">PDF</a></td>
	    </tr>
		</table>
	</div>
</div>
</body>
</html>