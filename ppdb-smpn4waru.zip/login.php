<?php 
session_start();

include 'koneksi.php';
 
$nisn = $_POST['nisn'];
$password = $_POST['password'];

$sql= "SELECT * from login where nisn='$nisn' and password='$password'";
$query = mysqli_query($koneksi, $sql);
$cek = mysqli_num_rows($query);
if($cek > 0){
	$data = mysqli_fetch_assoc($query);
	if($data['level']=="admin"){
		$_SESSION['nisn'] = $nisn;
		$_SESSION['level'] = "admin";
		header("location:user/admin/homeadmin.php");
	}else if($data['level']=="siswa"){
		$_SESSION['nisn'] = $nisn;
		$_SESSION['level'] = "siswa";
		header("location:user/homeakun.php");
	}else{
		header("location:hallogin.php?pesan=gagal");
	}	
}else{
	header("location:hallogin.php?pesan=gagal");
}
?>