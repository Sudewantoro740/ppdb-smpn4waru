<!DOCTYPE html>
<html>
<head>
	<title>Informasi PPDB Online SMPN 4 Waru</title>
	<link rel="icon" href="gambar/logo.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
	<style type="text/css">
		body {
			background-color: #e3e1e1;
		}
		.header {
			padding: 80px;
			text-align: center;
			display: flex;
			justify-content: center;
			height: 60vh;
			flex-direction: column;
			align-items: center;
		}
	</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<a class="navbar-brand" href="halutama.php">
    	<img src="gambar/logo.png" width="55" height="50" class="d-inline-block align-center"> SMPN 4 WARU
  	</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item">
				<a class="nav-link" href="index.php">Home</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="hallogin.php">Login</a>
			</li>
			<li class="nav-item">
        		<a class="nav-link" href="daftarakun.php">Registrasi</a>
      		</li>
			<li class="nav-item active">
        		<a class="nav-link" href="informasi.php">Informasi</a>
      		</li>
      		<li class="nav-item">
        		<a class="nav-link" href="tentang.php">Tentang</a>
      		</li>
		</ul>
		<span class="navbar-text">
      		PPDB Online SMPN 4 Waru
    	</span>
	</div>
</nav>

<div class="container" style="padding-top: 50px;">
<div class="row">
<div class="col">
	<div class="card-header bg-dark text-white">
		<h4>Informasi Pendaftaran</h4>
	</div>
	<div class="card-body bg-white">
		<ol>
			<li>Pertama silahkan login <a href="login.php">disini</a>. Jika belum mempunyai akun maka silahkan daftar <a href="daftarakun.php">disini</a>.</li>
			<li>Setelah masuk ke akun anda, siapkan data - data yang akan diperlukan.</li>
			<li>Lalu masukkan data tersebut kedalam kolom pendaftaran.</li>
			<li>Setelah selesai mengisi kolom pendaftaran, maka klik cetak dan bawa saat daftar ulang.</li>
			<li>Pendaftaran lebih lanjut akan dihubungi oleh pihak sekolah.</li>
		</ol>
		<p>Semua informasi tentang pembukaan pendaftaran, syarat, jadwal dan lain-lain bisa membuka website PPDB Surabaya 2020 atau klik <a href="https://ppdb.surabaya.go.id/">disini</a>.</p>
	</div>
</div>
</div>
</div>
</body>
</html>