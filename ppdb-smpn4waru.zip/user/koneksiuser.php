<?php 
$host       = "localhost";
$user       = "id13904619_ppdbsmpn4waru";
$pass   	= "PemrogramanwebUAS-2020";
$database   = "id13904619_smpn4waru";
$koneksi    = mysqli_connect($host, $user, $pass, $database);
?>