<!DOCTYPE html>
<html>
<meta charset="utf-8">
<head>
	<title>Registrasi PPDB Online SMPN 4 Waru</title>
	<link rel="icon" href="gambar/logo.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
 	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	<style type="text/css">
		body {
			background-color: #e3e1e1;
		}
		.header {
			padding: 80px;
			text-align: center;
			display: flex;
			justify-content: center;
			height: 60vh;
			flex-direction: column;
			align-items: center;
		}
	</style>
</head>
<?php
$error_nama = "";
$error_nisn = "";
$error_password = "";
$error_kpassword = "";
$error_check = "";
$nama = "";
$nisn = "";
$password = "";
$kpassword = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	if (empty($_POST["nama"])) {
		$error_nama = "Nama Tidak Boleh Kosong";
	}
	else {
		$nama = cek_input($_POST["nama"]);
		if (!preg_match("/^[a-zA-Z ]*$/",$nama)) {
			$error_nama = "Inputan Hanya Boleh Huruf dan Spasi";
		}
	}

 	if (empty($_POST["nisn"])) {
		$error_nisn = "NISN Tidak Boleh Kosong";
	}
	else {
		$nisn = cek_input($_POST["nisn"]);
		if (strlen($nisn) != '10') {
        	$error_nisn = "NISN Anda Harus Berisi 10 Karakter!";
	    }
		else if (!is_numeric($nisn)) {
			$error_nisn = 'NISN Hanya Boleh Angka';
		}
	}

	if (empty($_POST["password"])) {
		$error_password = "Password Tidak Boleh Kosong";
	}
	else {
		$password = cek_input($_POST["password"]);
		if (strlen($_POST["password"]) <= '7') {
        	$error_password = "Password Anda Harus Berisi Setidaknya 8 Karakter!";
	    }
	    elseif(!preg_match("#[0-9]+#",$password)) {
	        $error_password = "Passsword Anda Harus Berisi Sedikitnya 1 Angka!";
	    }
	    elseif(!preg_match("#[A-Z]+#",$password)) {
	        $error_password = "Password Anda Harus Berisi Setidaknya 1 Huruf Capital!";
	    }
	    elseif(!preg_match("#[a-z]+#",$password)) {
	        $error_password = "Password Anda Harus Berisi Sedikitnya 1 Huruf Kecil!";
	    }
	}

	if (empty($_POST["kpassword"])) {
		$error_kpassword = "Password Tidak Boleh Kosong";
	}
	else {
		$kpassword = cek_input($_POST["kpassword"]);
		if ($_POST["password"] != $_POST["kpassword"]) {
        	$error_kpassword = "Password Anda Harus Sama!";
	    }
		elseif (strlen($_POST["kpassword"]) <= '7') {
        	$error_kpassword = "Password Anda Harus Berisi Setidaknya 8 Karakter!";
	    }
	    elseif(!preg_match("#[0-9]+#",$kpassword)) {
	        $error_kpassword = "Passsword Anda Harus Berisi Sedikitnya 1 Angka!";
	    }
	    elseif(!preg_match("#[A-Z]+#",$kpassword)) {
	        $error_kpassword = "Password Anda Harus Berisi Setidaknya 1 Huruf Capital!";
	    }
	    elseif(!preg_match("#[a-z]+#",$kpassword)) {
	        $error_kpassword = "Password Anda Harus Berisi Sedikitnya 1 Huruf Kecil!";
	    }
	}

	if(empty($nama && $nisn && $password )){
		$error_check = "pastikan semua data terisi";
	} 
	else {
		include "simpanakun.php";
		if (mysqli_num_rows($qry)==1) {
		header("location:daftarakun.php?pesandaftar=punya");
	    }else{
		$level = "siswa";
		$sql = "INSERT INTO `login`(`level`,`nama`,`nisn`,`password`) VALUES ('$level','$nama','$nisn','$password')";
		mysqli_query($koneksi,$sql) or die (mysqli_error());
		header("location:daftarakun.php?pesandaftar=sudah");
	    }
	}
}
function cek_input($data){
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;	
}
?>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<a class="navbar-brand" href="halutama.php">
    	<img src="gambar/logo.png" width="55" height="50" class="d-inline-block align-center"> SMPN 4 WARU
  	</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item">
				<a class="nav-link" href="index.php">Home</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="hallogin.php">Login</a>
			</li>
			<li class="nav-item active">
        		<a class="nav-link" href="daftarakun.php">Registrasi</a>
      		</li>
			<li class="nav-item">
        		<a class="nav-link" href="informasi.php">Informasi</a>
      		</li>
      		<li class="nav-item">
        		<a class="nav-link" href="tentang.php">Tentang</a>
      		</li>
		</ul>
		<span class="navbar-text">
      		PPDB Online SMPN 4 Waru
    	</span>
	</div>
</nav>

<div class="container" style="padding-top: 50px;">
<div class="row">
<div class="col-sm-2"></div>
<div class="col-sm-8">
	<div class="card-header bg-dark text-white">
		<h4>Registrasi Akun Baru</h4>
	</div>
	<div class="card-body bg-white">
	<?php 
		if(isset($_GET['pesandaftar'])){
			if($_GET['pesandaftar'] == "punya"){
				echo '<div class="alert alert-warning" role="alert">Anda sudah memiliki akun, silahkan login di kolom login</div>';
			}else if($_GET['pesandaftar'] == "sudah"){
				echo '<div class="alert alert-success" role="alert">Akun telah berhasil teregistrasi</div>';
			}
		}
	?>
	<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" data-js-validate="true" data-js-highlight-state-msg="true" data-js-show-valid-msg="true">
		<div class="form-group row">    
			<label for="nama" class="col-sm-4 col-form-label"> Nama Lengkap </label>
			<div class="col-sm-8">
			<input type="text" name="nama" class="text-capitalize form-control <?php echo ($error_nama !="" ? "is-invalid" : "");?>" id="nama" placeholder="Nama" value="<?php echo $nama;?>"><span class="warning"><?php echo $error_nama;?></span>
			</div>
		</div>

		<div class="form-group row">    
			<label for="nisn" class="col-sm-4 col-form-label"> NISN </label>
			<div class="col-sm-8">
			<input type="text" name="nisn" class="form-control <?php echo ($error_nisn !="" ? "is-invalid" : "");?>" id="nisn" placeholder="NISN" value="<?php echo $nisn;?>"><span class="warning"><?php echo $error_nisn;?></span>
			</div>
		</div>

		<div class="form-group row">    
			<label for="password" class="col-sm-4 col-form-label"> Password </label>
			<div class="col-sm-8">
			<input type="password" name="password" class="form-control <?php echo ($error_password !="" ? "is-invalid" : "");?>" id="password" placeholder="Password" value="<?php echo $password;?>"><span class="warning"><?php echo $error_password;?></span>
			</div>
		</div>
			<div class="form-group row">    
			<label for="nisn" class="col-sm-4 col-form-label"> Konfrimasi Password </label>
			<div class="col-sm-8">
			<input type="password" name="kpassword" class="form-control <?php echo ($error_kpassword !="" ? "is-invalid" : "");?>" id="kpassword" placeholder="Konfirmasi Password" value="<?php echo $kpassword;?>"><span class="warning"><?php echo $error_kpassword;?></span>
			</div>
		</div>
		<div class="form-group row">
			<div class="col-sm-8"></div>
			<div class="col-sm-4">
				<button type="reset" class="btn btn-outline-danger"> Reset</button>
				<button type="submit" class="btn btn-outline-success"> Registrasi</button>
			</div>	
		</div>
	</form>
</div>
<div class="col-sm-2"></div>
</div>
</div>
</body>
</html>