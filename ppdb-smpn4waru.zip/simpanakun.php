<?php
include "koneksi.php";
$sql2="SELECT nisn FROM login where nisn = '".$nisn."'";
$qry = mysqli_query($koneksi, $sql2) or die ("Proses cetak gagal");
	
?>