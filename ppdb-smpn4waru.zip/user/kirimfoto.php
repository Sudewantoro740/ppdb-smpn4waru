<?php
session_start();
if($_SESSION['level']==""){
	header("location:../hallogin.php?pesan=belum_login");
}
include "koneksiuser.php";
// Ambil Data yang Dikirim dari Form
$nisn = $_SESSION['nisn'];
$nama_file = $_FILES['img1']['name'];
$lokasi = $_FILES['img1']['tmp_name'];
// Set path folder tempat menyimpan gambarnya
$path = "foto_siswa/".$nama_file;
    // Proses upload
  $sql2="SELECT nisn FROM foto where nisn = '".$nisn."'";
  $qry = mysqli_query($koneksi, $sql2) or die ("Proses cetak gagal");
  if (mysqli_num_rows($qry)==1) {
    header("location:homeakun.php?pesanfoto=sudah");
  }else{
    if(move_uploaded_file($lokasi, $path)){ // Cek apakah gambar berhasil diupload atau tidak
    	// Jika gambar berhasil diupload, Lakukan :  
    	// Proses simpan ke Database
    	$query = "INSERT INTO foto(nisn,namafoto) VALUES('".$nisn."','".$nama_file."')";
    	$sql = mysqli_query($koneksi, $query); // Eksekusi/ Jalankan query dari variabel $query
    
    	if($sql){ // Cek jika proses simpan ke database sukses atau tidak
      // Jika Sukses, Lakukan :
      header("location: homeakun.php"); // Redirectke halaman index.php
    	}else{
      // Jika Gagal, Lakukan :
      header("location:homeakun.php?pesanfoto=gagal");
    	}
    }else{
      // Jika gambar gagal diupload, Lakukan :
      header("location:homeakun.php?pesanfoto=gagal");
    }
  }
?>
