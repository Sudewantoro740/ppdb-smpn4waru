<?php 
session_start();
if($_SESSION['level']==""){
	header("location:../hallogin.php?pesan=belum_login");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>PPDB Online SMPN 4 Waru</title>
	<link rel="icon" href="../gambar/logo.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
 	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	<style type="text/css">
		body {
			background-color: #e3e1e1;
		}
		.header {
			padding: 80px;
			text-align: center;
			display: flex;
			justify-content: center;
			height: 60vh;
			flex-direction: column;
			align-items: center;
		}
	</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<a class="navbar-brand" href="https://www.smpn4waru.sch.id/">
    	<img src="../gambar/logo.png" width="55" height="50" class="d-inline-block align-center"> SMPN 4 WARU
  	</a>

	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item active">
				<a class="nav-link" href="homeakun.php">Home <span class="sr-only">(current)</span></a>
			</li>
			<li class="nav-item">
        		<a class="nav-link" href="pendaftaran.php">Pendaftaran</a>
      		</li>
			<li class="nav-item">
        		<a class="nav-link" href="informasiakun.php">Informasi</a>
      		</li>
		</ul>
		<ul class="navbar-nav ml-auto">
			<li class="nav-item">
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#logout">
  					Log Out
				</button>
	      	</li>	
		</ul>
    </div>
</nav>
<div class="modal" id="logout">
    <div class="modal-dialog">
      	<div class="modal-content">
	        <div class="modal-header">
	          	<h4 class="modal-title">Log Out</h4>
	          	<button type="button" class="close" data-dismiss="modal">&times;</button>
	        </div>
	        <div class="modal-body">
	          	Apakah Yakin Ingin Keluar?
	        </div>
	        <div class="modal-footer">
        		<a href="logout.php" class="btn btn-primary">Log Out</a>
	          	<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
	        </div>
      	</div>
    </div>
</div>
<div class="container" style="padding-top: 60px;">
<div class="row">
<div class="col-sm-4">
	<div class="card-body bg-white" style="height: 410px">
		<?php
		include "koneksiuser.php";
		$nisn = $_SESSION['nisn'];
		$query = "SELECT * FROM foto where nisn = '".$nisn."'"; // Tampilkan semua data gambar
		$sql = mysqli_query($koneksi, $query); // Eksekusi/Jalankan query dari variabel $query
		$row = mysqli_num_rows($sql); // Ambil jumlah data dari hasil eksekusi $sql
		if($row > 0){ // Jika jumlah data lebih dari 0 (Berarti jika data ada)
		  	while($data = mysqli_fetch_array($sql)){ // Ambil semua data dari hasil eksekusi $sql
		  	echo "<div class='z-depth-1-half mb-4' align='center'>
      				<img src='foto_siswa/".$data['namafoto']."' class='img-thumbnail w-50 p-3' alt='Foto Siswa'>
    			</div>";
		  	}
		}else{ // Jika data tidak ada
		  	echo '<div class="z-depth-1-half mb-4" align="center">
      				<img src="../gambar/user.png" class="img-thumbnail w-50 p-3" alt="Foto Siswa">
    			</div>';
    		echo('<div class="alert alert-warning" role="alert">Foto belum ada, gunakan NISN anda sebagai nama foto</div>');
		}
		?>
    	
		<form class="md-form" action="kirimfoto.php" method="post" enctype="multipart/form-data">
		  	<div class="file-field">
		    	<div class="d-flex justify-content-center">
		      		<div class="btn float-left">
				        <input type="file" name="img1">
				        <input type="submit" name="Upload">
		      		</div>
		    	</div>
		  	</div>
		</form>
		<?php 
			if(isset($_GET['pesanfoto'])){
				if($_GET['pesanfoto'] == "gagal"){
					echo '<div class="alert alert-warning" role="alert">Maaf, gambar gagal diupload</div>';
				}else if($_GET['pesanfoto'] == "sudah"){
					echo '<div class="alert alert-success" role="alert">Anda sudah mengupload gambar</div>';
				}
			}
		?>
	</div>
</div>
<div class="col-sm-8">
	<div class="card-body bg-white" style="height: 410px">
		<h2 style="padding-left: 15px;">Selamat Datang NISN <b><?php echo $_SESSION['nisn']; ?></b></h2>
		<div style="padding-left: 50px; padding-top: 30px; font-size: 25px">
			<?php
			include 'koneksiuser.php';
			$nisn = $_SESSION['nisn'];
			$sql="SELECT nama,nisn FROM login where nisn = '".$nisn."'";
			$qry = mysqli_query($koneksi, $sql) or die ("Proses cetak gagal");
			$no=1;
			while($row=mysqli_fetch_row($qry)){
				echo "<table class='text-capitalize'>
				<tr>
					<td>Nama</td>
					<td> :</td>
					<td>" .$row[0]."</td>
				</tr>
				<tr>
					<td>NISN</td>
					<td> :</td>
					<td>" .$row[1]."</td>
				</tr>
				</table>";
				$no++;
			}

			$sql2="SELECT nisn FROM formulir where nisn = '".$nisn."'";
			$qry = mysqli_query($koneksi, $sql2) or die ("Proses cetak gagal");
			if (mysqli_num_rows($qry)==0) {
				echo "<table>
				<tr>
					<td>Data</td>
					<td> :</td>
					<td> Belum Terisi</td>
				</tr>
				</table>
				<div style='padding-top: 80px; padding-right: 50px;'><div class='alert alert-warning' role='alert' style='font-size: 15px'>Anda tidak bisa mencetak karena anda belum mengisi data di pendaftaran</div></div>";
			}else {
				echo "<table>
				<tr>
					<td>Data</td>
					<td> :</td>
					<td> Sudah Terisi</td>
				</tr>
				</table>
				<p style='font-size: 15px; padding-top: 80px';>Cetak Untuk Daftar Ulang</p>
				<div class='col-sm-8'>
					<a href='cetakpdfsiswa.php' class='btn btn-outline-success'>Cetak</a>
				</div>";
			}
			?>
		</div>
		
	</div>
</div>
</body>
</html>